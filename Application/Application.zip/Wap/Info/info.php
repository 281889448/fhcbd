<?php
/**
 * 所属项目 110.
 * 开发者: 陈一枭
 * 创建日期: 2014-11-18
 * 创建时间: 10:14
 * 版权所有 想天软件工作室(www.ourstu.com)
 */

return array(
    //模块名
    'name' => 'Wap',
    //别名
    'alias' => '手机端',
    //版本号
    'version' => '1.0.0',
    //是否商业模块,1是，0，否
    'is_com' => 0,
    //是否显示在导航栏内？  1是，0否
    'show_nav' => 1,
    //模块描述
    'summary' => '手机端模块',
    //开发者
    'developer' => 'MR.Z',
    //开发者网站
    'website' => '###',
    //前台入口，可用U函数
    'entry' => 'Wap/index/index'

);