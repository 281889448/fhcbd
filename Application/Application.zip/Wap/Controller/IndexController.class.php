<?php
/**
 * Created by PhpStorm.
 * User: MR.Z
 * Date: 16-10-8
 * Time: AM9:45
 */

namespace Wap\Controller;

use Common\Controller\BaseController;


class IndexController extends BaseController
{

	public function index(){
		$this->display();
	}

	public function add(){

    }
}